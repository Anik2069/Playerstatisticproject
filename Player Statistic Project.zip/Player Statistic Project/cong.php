<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home Page</title>
<link href="css/cong.css" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=Play" rel="stylesheet">
</head>

<body>
<div class="cong">
    <form>
        <a href="add.php"><input type="button" value="Add Player Info"></a> <br><br>
        <a href="Update.php"><input type="button" value="Add Player Statistic"></a> <br><br>
        <a href="Updatestate1.php"><input type="button" value="Update Player Statistic"></a> <br><br>
        <a href="Updatestate.php"><input type="button" value="View Player Info"></a> <br><br>
        <a href="rating.php"><input type="button" value="Update Player Rating"></a> <br><br>
        <a href="makeSchedule.php"><input type="button" value="Update Schedule"></a> <br><br>

        <a href="logn.php" style="text-decoration: none">Go back to Home page</a>
        <br><br>
    </form>
    
    </div>
</body>
</html>
